#include <stdio.h>
#include <math.h>


 char* gezegenler[] = {"Merkur", "Venus", "Dunya", "Mars", "Jupiter", "Saturn", "Uranus", "Neptun"};
float yercekimiIvmeleri[] = {3.70, 8.87, 9.81, 3.71, 24.79, 10.44, 8.69, 11.15};
 int GezegenSayısı = 8;
 float PI = 3.14159;

         void serbestDusme(float *YerCekimi);
         void yukariAtis(float *YerCekimi);
         void agirlikDeneyi(float *YerCekimi);
         void potansiyelEnerji(float *YerCekimi);
         void hidrostatikBasinc(float *YerCekimi);
         void arsimetKuvveti(float *YerCekimi);
         void basitSarkac(float *YerCekimi);
         void sabitIpGerilmesi(float *YerCekimi);
         void asansorDeneyi(float *YerCekimi);

int main() {
    char bilimInsani[50];
    int secim = 0;

    printf("     UZAY SIMULASYONU   \n");
    printf("Sayin Biilim İnsani adinizi  giriniz: ");
    scanf("%s", bilimInsani);

    while (1) {
        printf("\nSayin %s, lutfen bir deney seciniz (Simulasyondan cikmak icin: -1):\n", bilimInsani);
        printf("1. Serbest Dusme\n2. Yukari Atis\n3. Agirlik\n4. Potansiyel Enerji\n5. Hidrostatik Basinc\n6. Arsimet Kuvveti\n7. Basit Sarkac\n8. Sabit Ip Gerilmesi\n9. Asansor Deneyi\nSecim: ");
        scanf("%d", &secim);

        if (secim == -1) break;

        switch (secim) {
            case 1: serbestDusme(yercekimiIvmeleri);
            break;
            case 2: yukariAtis(yercekimiIvmeleri);
            break;
            case 3: agirlikDeneyi(yercekimiIvmeleri);
            break;
            case 4: potansiyelEnerji(yercekimiIvmeleri);
            break;
            case 5: hidrostatikBasinc(yercekimiIvmeleri);
            break;
            case 6: arsimetKuvveti(yercekimiIvmeleri);
            break;
            case 7: basitSarkac(yercekimiIvmeleri);
            break;
            case 8: sabitIpGerilmesi(yercekimiIvmeleri);
            break;
            case 9: asansorDeneyi(yercekimiIvmeleri);
            break;
            default: printf("Tanimsiz Secim!\n");
        }
    }
    return 0;
}


void serbestDusme(float *YerCekimi) {   /*Bu deneyde ortamın hava direnci (sürtünme kuvveti) ihmal
                                        edilmektedir. Kullanıcıdan süre (t) saniye cinsinden istenmelidir. Bu süre boyunca ne kadar
                                        yol kat ettiği (h) metre cinsinden hesaplanacaktır. Aşağıdaki formül kullanılacaktır.
                                        ℎ = 0.5*g*t*t  */

    float t;
    printf("Sure (t) saniye: ");
    scanf("%f", &t);
    t = (t < 0) ? -t : t;
    for (int i = 0; i < GezegenSayısı; i++) {
        float h = 0.5 * *(YerCekimi + i) * t * t;
        printf("%s: Dusme mesafesi = %.5f m\n", *(gezegenler + i), h);
    }
}

void yukariAtis(float *YerCekimi) {                                   /*Bu deneyde ortamın hava direnci (sürtünme kuvveti) ihmal
                                                                        edilmektedir. Kullanıcıdan cismin kaç m/s hızla fırlatıldığı (𝑣0) istenmelidir.
                                                                        sonucunda cismin maksimum çıkabileceği yükseklik (ℎ ) metre cinsinden hesaplanmalıdır.
                                                                        h max= v0*v0/2g */
    float v0;
    printf("Ilk hiz (v0) m/s: ");
    scanf("%f", &v0);
    v0 = (v0 < 0) ? -v0 : v0;
    for (int i = 0; i < GezegenSayısı; i++) {
        float h_max = (v0 * v0) / (2 * *(YerCekimi + i));
        printf("%s: Maksimum yukseklik = %.5f m\n", *(gezegenler + i), h_max);
    }
}

void agirlikDeneyi(float *YerCekimi) {                                /* Bu deneyde kütlesi (m) kg cinsinden kullanıcıdan istenen bir cismin
                                                                        ağırlığı (G) hesaplanmalıdır.
                                                                                      G=mg  */
    float m;
    printf("Kutle (m) kg: ");
    scanf("%f", &m);
    m = (m < 0) ? -m : m;
    for (int i = 0; i < GezegenSayısı; i++) {
        float G = m * *(YerCekimi + i);
        printf("%s: Agirlik = %.5f Newton\n", *(gezegenler + i), G);
    }
}

void potansiyelEnerji(float *YerCekimi) {                         /*   Bu enerji, bir kütlenin kütleçekimi alanında
                                                                       bulunduğu yerden dolayı sahip olduğu enerjidir. Yüksekliği (h) metre, kütlesi (m) kg
                                                                       cinsinden kullanıcıdan istenen bir cismin kütleçekimsel potansiyel enerjisi (𝐸p) hesaplanacaktır
                                                                                       Ep= mgh  */


    float m, h;
    printf("Kutle (m) kg: ");
    scanf("%f", &m);
    printf("Yukseklik (h) m: "); scanf("%f", &h);
    m = (m < 0) ? -m : m; h = (h < 0) ? -h : h;
    for (int i = 0; i < GezegenSayısı; i++) {
        float Ep = m * *(YerCekimi + i) * h;
        printf("%s: Potansiyel Enerji = %.5f Joule\n", *(gezegenler + i), Ep);
    }
}

void hidrostatikBasinc(float *YerCekimi) {                        /*   Sıvının temas yüzeyinin birim alanına uyguladığı dik kuvvete hidrostatik basınç denir.
                                                                       Sıvının birim hacmindeki kütlesi (ρ, rho) 𝑘𝑔/𝑚*m*m cinsinden,
                                                                       derinliği (h) ise metre cinsinden kullanıcıdan istenmelidir. Bu sıvının ilgili derinlikte
                                                                       yüzeyine uyguladığı hidrostatik basınç (P) hesaplanmalıdır
                                                                                                  P=ρgh     */
    float rho, h;
    printf("Sivi yogunlugu (rho) kg/m3: ");
    scanf("%f", &rho);
    printf("Derinlik (h) m: ");
    scanf("%f", &h);
    rho = (rho < 0) ? -rho : rho; h = (h < 0) ? -h : h;
    for (int i = 0; i < GezegenSayısı; i++) {
        float P = rho * *(YerCekimi + i) * h;
        printf("%s: Hidrostatik Basinc = %.5f Pascal\n", *(gezegenler + i), P);
    }
}

void arsimetKuvveti(float *YerCekimi) {                     /*      Sıvı içerisindeki cisme uygulanan kaldırma kuvvet (𝐹k) hesaplanmalıdır.
                                                                    Sıvının birim hacmindeki kütlesi (ρ , rho) cinsinden,
                                                                    cismin batan hacmi (V) m*m*m cinsinden kullanıcıdan istenmelidir
                                                                                               Fk=ρgV      */
    float rho, V;
    printf("Sivi yogunlugu (rho) kg/m3: ");
    scanf("%f", &rho);
    printf("Batan hacim (V) m3: ");
    scanf("%f", &V);
    rho = (rho < 0) ? -rho : rho; V = (V < 0) ? -V : V;
    for (int i = 0; i < GezegenSayısı; i++) {
        float Fk = rho * *(YerCekimi + i) * V;
        printf("%s: Kaldirma Kuvveti = %.5f Newton\n", *(gezegenler + i), Fk);
    }
}

void basitSarkac(float *YerCekimi) {                  /*            Serbest durumda bulunan, ucunda W ağırlıklı cisim asılı olan sarkacın basit harmonik hareket yaptığı varsayılmaktadır.
                                                                    Sarkacın uzunluğu (L) metre cinsinden kullanıcıdan istenmelidir.
                                                                    Bunun sonucunda sarkacın ilk konumundan (soldan başladığını varsayalım) ikinci konumuna (sağ en üst salınım bölgesine) ve sonra
                                                                    tekrar başlangıç konumuna gidene kadar geçen süre (T) saniye türünden hesaplanmalıdır.
                                                                                               T=2*PI * sqrt(L/g)       */

    float L;
    printf("Sarkac uzunlugu (L) m: ");
    scanf("%f", &L);
    L = (L < 0) ? -L : L;
    for (int i = 0; i < GezegenSayısı; i++) {
        float T = 2 * PI * sqrt(L / *(YerCekimi + i));
        printf("%s: Periyot = %.5f saniye\n", *(gezegenler + i), T);
    }
}

void sabitIpGerilmesi(float *YerCekimi) {                   /*      Ucunda m kütleli bir cismin asılı olduğu,
                                                                    kütlesiz ve esnemez bir ip düşey doğrultuda asılıdır.
                                                                    Cismin kütlesi kullanıcıdan istenilecektir.
                                                                    İpin gerilme kuvveti (T) hesaplanmalıdır.
                                                                                      T=mg         */
    float m;
    printf("Kutle (m) kg: ");
    scanf("%f", &m);
    m = (m < 0) ? -m : m;
    for (int i = 0; i < GezegenSayısı; i++) {
        float T = m * *(YerCekimi + i);
        printf("%s: Ip Gerilmesi T = %.5f Newton\n", *(gezegenler + i), T);
    }
}

void asansorDeneyi(float *YerCekimi) {                   /*        Asansör problemi seçildiğinde kullanıcıdan asansörün ivmesi (a)istenmelidir.
                                                                   Asansörün ivmesine bağlı olarak içindeki cismin hissettiği ağırlık değişmektedir.
                                                                   Asansör ivmelenerek yükseliyorsa cismin hissedilen ağırlığı artacaktır.
                                                                   Asansör ivmenelerek iniyorsa cismin hissedilen ağırlığı azalacaktır.
                                                                   Buna göre kullanıcıdan asansörün ivmesi 𝑚/𝑠*s biriminde ve cismin kütlesi (m) kg biriminde istenildiğinde cismin etkin ağırlığı (Newton) N biriminden hesaplanmalıdır.
                                                                   Asansör yukarı yönde ivmelenerek hızlanıyorsa veya aşağı yönde ivmelenerek yavaşlıyorsa:
                                                                                                    N=m(g+a)

                                                                   Asansör aşağı yönde ivmelenerek hızlanıyorsa veya yukarı yönde ivmelenerek yavaşlıyorsa:
                                                                                                   N=m(g-a)     */

    float m, a;
    int durum;
    printf("Kutle (m) kg: ");
    scanf("%f", &m);
    printf("Asansor ivmesi (a) m/s2: ");
    scanf("%f", &a);
    printf("Durum Secin:\n1. Yukari hizlanan / Asagi yavaslayan\n2. Asagi hizlanan / Yukari yavaslayan\nSecim: ");
    scanf("%d", &durum);
    m = (m < 0) ? -m : m; a = (a < 0) ? -a : a;
    for (int i = 0; i < GezegenSayısı; i++) {
        float g = *(YerCekimi + i);
        float N = (durum == 1) ? m * (g + a) : m * (g - a);
        printf("%s: Hissedilen Agirlik = %.5f N\n", *(gezegenler + i), N);
    }
}
